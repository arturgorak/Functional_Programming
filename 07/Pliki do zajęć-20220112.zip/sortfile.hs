import System.IO
import System.Environment

-- Funkcja wczytuje linijka po linijce i wynik opakowuje w monade IO
readFileToList :: Handle -> IO [Integer]
--TODO


qsort :: [Integer] -> [Integer]
qsort [] = []
qsort (x:xs) = (qsort left) ++ [x]++(qsort right)
		where 
		    left = [y|y<-xs,y<=x]
		    right = [y|y<-xs,y>x]
		    
-- Funkcja zapisujaca liste do pliku
writeListToFile :: [Integer] -> Handle->IO ()
--TODO


main = do
          (inFileName:outFileName:_) <-getArgs
          inFileHandle  <- openFile inFileName ReadMode
          outFileHandle <- openFile outFileName WriteMode
          list <- readFileToList inFileHandle
          writeListToFile (qsort list) outFileHandle
          hClose inFileHandle
          hClose outFileHandle
          
          